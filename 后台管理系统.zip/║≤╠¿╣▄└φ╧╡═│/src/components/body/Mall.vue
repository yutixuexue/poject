<template>
  <Main>mall</Main>
</template>

<script>
import Main from "../Main";

export default {
  name: "Mall",
  components: {
    Main,
  },
};
</script>

<style>
</style>