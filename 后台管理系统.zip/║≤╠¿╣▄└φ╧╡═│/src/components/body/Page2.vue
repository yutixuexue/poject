<template>
  <Main>page2</Main>
</template>

<script>
import Main from "../Main";

export default {
  name: "Page2",
  components: {
    Main,
  },
};
</script>

<style>
</style>