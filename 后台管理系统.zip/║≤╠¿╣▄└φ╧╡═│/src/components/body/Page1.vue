<template>
  <Main>page1</Main>
</template>

<script>
import Main from "../Main";

export default {
  name: "Page1",
  components: {
    Main,
  },
};
</script>

<style>
</style>